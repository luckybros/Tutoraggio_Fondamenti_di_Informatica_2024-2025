#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PARTITE 100

typedef struct {
    char squadra1[50];
    char squadra2[50];
    int gol1;
    int gol2;
    char data[11];  // "gg/mm/aaaa"
    char luogo[50];
} Partita;

void inserisciPartita(Partita** partite, int* numeroPartite);
void stampaPartitePerData(Partita partite[], int numeroPartite, char data[]);
void calcolaPuntiGiocate(Partita partite[], int numeroPartite, char squadra[], int* punti, int* partiteGiocate);

int main() {
    Partita* partite = NULL;  // array dinamico
    int numeroPartite = 0;
    
    int scelta;
    do {
        printf("\nMenu:\n");
        printf("1. Inserisci partita\n");
        printf("2. Stampa partite per data\n");
        printf("3. Calcola punti e partite giocate per squadra\n");
        printf("4. Esci\n");
        printf("Scegli un'opzione: ");
        scanf("%d", &scelta);
        
        switch (scelta) {
            case 1:
                inserisciPartita(&partite, &numeroPartite);
                break;
            case 2: {
                char data[11];
                printf("Inserisci la data (gg/mm/aaaa): ");
                scanf("%s", data);
                stampaPartitePerData(partite, numeroPartite, data);
                break;
            }
            case 3: {
                char squadra[50];
                printf("Inserisci il nome della squadra: ");
                scanf("%s", squadra);
                int punti, partiteGiocate;
                calcolaPuntiGiocate(partite, numeroPartite, squadra, &punti, &partiteGiocate);
                printf("La squadra %s ha totalizzato %d punti e ha giocato %d partite.\n", squadra, punti, partiteGiocate);
                break;
            }
            case 4:
                printf("Uscita dal programma.\n");
                break;
            default:
                printf("Scelta non valida.\n");
                break;
        }
    } while (scelta != 4);
    
    free(partite);
    return 0;
}

void inserisciPartita(Partita** partite, int* numeroPartite) {
    
    if (*numeroPartite >= MAX_PARTITE) {
        printf("Numero massimo di partite raggiunto!\n");
        return;
    }
    
    // Ridimensioniamo la memoria per aggiungere una nuova partita
    *partite = realloc(*partite, (*numeroPartite + 1) * sizeof(Partita));

    printf("Inserisci i dati della partita:\n");
    printf("Squadra 1: ");
    scanf("%s", (*partite)[*numeroPartite].squadra1);
    printf("Squadra 2: ");
    scanf("%s", (*partite)[*numeroPartite].squadra2);
    printf("Gol fatti da %s: ", (*partite)[*numeroPartite].squadra1);
    scanf("%d", &(*partite)[*numeroPartite].gol1);
    printf("Gol fatti da %s: ", (*partite)[*numeroPartite].squadra2);
    scanf("%d", &(*partite)[*numeroPartite].gol2);
    printf("Data (gg/mm/aaaa): ");
    scanf("%s", (*partite)[*numeroPartite].data);
    printf("Luogo: ");
    scanf("%s", (*partite)[*numeroPartite].luogo);
    (*numeroPartite)++;
}

void stampaPartitePerData(Partita partite[], int numeroPartite, char data[]) {
    int trovate = 0;
    for (int i = 0; i < numeroPartite; i++) {
        if (strcmp(partite[i].data, data) == 0) {
            printf("Partita tra %s e %s il %s, Luogo: %s\n", partite[i].squadra1, partite[i].squadra2, partite[i].data, partite[i].luogo);
            trovate = 1;
        }
    }

    if (!trovate) {
        printf("Nessuna partita trovata per la data %s.\n", data);
    }
}

void calcolaPuntiGiocate(Partita partite[], int numeroPartite, char squadra[], int* punti, int* partiteGiocate) {
    *punti = 0;
    *partiteGiocate = 0;

    for (int i = 0; i < numeroPartite; i++) {
        // Controlla se la squadra cercata è presente in entrambi i posti delle squadre per la partita
        if (strcmp(partite[i].squadra1, squadra) == 0 || strcmp(partite[i].squadra2, squadra) == 0) {
            (*partiteGiocate)++;

            if (strcmp(partite[i].squadra1, squadra) == 0) {
                if (partite[i].gol1 > partite[i].gol2) {
                    (*punti) += 3;  // vittoria
                } else if (partite[i].gol1 == partite[i].gol2) {
                    (*punti) += 1;  // pareggio
                }
            }

            if (strcmp(partite[i].squadra2, squadra) == 0) {
                if (partite[i].gol2 > partite[i].gol1) {
                    (*punti) += 3;  
                } else if (partite[i].gol2 == partite[i].gol1) {
                    (*punti) += 1; 
                }
            }
        }
    }
}


